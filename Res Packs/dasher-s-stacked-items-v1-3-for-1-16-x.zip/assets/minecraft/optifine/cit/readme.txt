In some updates, I will drastly re-work some items to get the texture count higher.
But if you don't like the new textures:
1. Check the item folder you don't like from a recent update to see if has a [Item name here]_old.zip file
2. Delete everything except the zip file
3. Extract the zip file
4. you're done!

Some Items will be removed in updates to the pack, but if you liked them, the zip files 
for them still exist in assets/minecraft/optifine/cit/items. Just unzip the zip files and 
you'll have them back!